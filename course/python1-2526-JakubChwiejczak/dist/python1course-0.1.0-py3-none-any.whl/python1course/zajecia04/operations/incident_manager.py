from ..fleet import *
from ..personnel import *
from .incident_queue import IncidentQueue


class IncidentManager:
    def __init__(self, stations):
        self.stations = stations
        self.incidentQueue = IncidentQueue

    def add_incident(self, incident):
        self.incidentQueue += incident


# def assign_ambulance(self,incident):
